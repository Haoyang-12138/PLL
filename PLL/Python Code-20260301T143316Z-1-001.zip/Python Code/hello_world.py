'''
First thing if not using the class laptops - install Python from
    the Python website (not the Windows store)
'''

import time

print("Hello world!")

time.sleep(3)

